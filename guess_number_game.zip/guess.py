import random

print("=== Игра: Угадай число ===")
print("Я загадал число от 1 до 100. Попробуй угадать!")

secret_number = random.randint(1, 100)
attempts = 0
max_attempts = 10

while attempts < max_attempts:
    try:
        guess = int(input("Введи число: "))
    except ValueError:
        print("Пожалуйста, вводи только числа.")
        continue

    attempts += 1

    if guess == secret_number:
        print(f"🎉 Поздравляю! Ты угадал за {attempts} попыток.")
        break
    elif guess < secret_number:
        print("📉 Моё число больше.")
    else:
        print("📈 Моё число меньше.")
else:
    print(f"😢 Ты не угадал. Моё число было: {secret_number}")
